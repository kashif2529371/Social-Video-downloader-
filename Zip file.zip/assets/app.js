function download() {
  const url = document.getElementById("videoUrl").value;

  if (!url) {
    alert("Please paste a video link");
    return;
  }

  document.getElementById("result").innerHTML =
    "✅ Link received! (Backend API later connect hogi)";
}